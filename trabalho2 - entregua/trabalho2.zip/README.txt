criar aplicativo

gcc -o meuPrograma main.c gerador.c editor.c lista.c lista.h editor.h exportador.c

./meuPrograma input.txt testo.bin 

Apenas o gerador usa estes argumentos, após isso informar o nome dos arquivos por comando.